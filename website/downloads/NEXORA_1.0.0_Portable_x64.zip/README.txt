﻿======================================================================
  NEXORA — Next-Gen Windows Performance & Care Engine (CleanMyMac X Theme)
  Portable Standalone Edition (v1.0.0-rc.1)
======================================================================

QUICK START:
1. Double-click "NEXORA.exe" to launch immediately.
2. No installation wizard, no registry modification, no administrator 
   privileges required.
3. Features CleanMyMac X-style 3-Stage Smart Scan, Space Lens bubble
   storage visualizer, and Win32 Kernel32 telemetry engine.
4. To remove, simply delete this unzipped folder.

SYSTEM REQUIREMENTS:
- Windows 10 (1809+) or Windows 11 (64-bit)
- Microsoft Edge WebView2 Runtime (preinstalled on Windows 10/11)

VERIFICATION:
Official SHA-256 Checksums available at https://nexorabeta.vercel.app/download
