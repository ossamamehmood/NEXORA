﻿======================================================================
  NEXORA — Ultra-Lightweight Windows Performance & Maintenance Engine
  Portable Standalone Edition (v1.0.0-rc.1)
======================================================================

QUICK START:
1. Double-click "NEXORA.exe" to launch immediately.
2. No installation wizard, no registry modification, no administrator 
   privileges required.
3. To remove, simply delete this unzipped folder.

SYSTEM REQUIREMENTS:
- Windows 10 (1809+) or Windows 11 (64-bit)
- Microsoft Edge WebView2 Runtime (preinstalled on Windows 10/11)

FEATURES INCLUDED:
- Win32 Kernel32 Live CPU & RAM Telemetry (Zero Console Flashing)
- Reversible Thread Scheduling & High-Performance Power Scheme
- Smart Storage Cleaner with Safe Quarantine Staging
- Privacy residue purger across Chrome, Edge, Firefox, and Brave
- Native Windows Diagnostic routines

VERIFICATION:
Official SHA-256 Checksums available at https://nexorabeta.vercel.app/download
