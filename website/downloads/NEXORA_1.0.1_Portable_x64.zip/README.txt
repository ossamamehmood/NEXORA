﻿======================================================================
  NEXORA — Next-Gen Windows Performance Suite (CleanMyMac X Theme)
  Portable Standalone Edition (v1.0.1 Production)
======================================================================

QUICK START:
1. Double-click "NEXORA.exe" to launch immediately.
2. No installer wizard, zero registry changes, zero administrator UAC prompts.
3. Completely portable and run-anywhere.
4. To remove, simply delete this unzipped folder.

SYSTEM REQUIREMENTS:
- Windows 10 (1809+) or Windows 11 (64-bit)
- Microsoft Edge WebView2 Runtime (preinstalled on Windows 10/11)

VERIFICATION:
Official SHA-256 Checksums available at https://nexorabeta.vercel.app/download
